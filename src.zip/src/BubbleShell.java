import java.util.Arrays;

public class BubbleShell {
    public static void main(String[] args) {
        //int[] arr = {75, 61, 42, 18, 98, 1, 67, 4, 98, 21, 9, 97, 23, 82, 17, 2, 37, 49, 4, 58};
        //int[] arr2 = {75, 61, 42, 18, 98, 1, 67, 4, 98, 21, 9, 97, 23, 82, 17, 2, 37, 49, 4, 58};
        //int[] arr3 = {75, 61, 42, 18, 98, 1, 67, 4, 98, 21, 9, 97, 23, 82, 17, 2, 37, 49, 4, 58};

        int[] arr = HybridShellQuickSort.generateRandomArray(10000);
        int[] arr2 = HybridShellQuickSort.generateRandomArray(10000);
        int[] arr3 = HybridShellQuickSort.generateRandomArray(10000);

        CodeTimer.timeCode(() -> ShellSort.shellSort(arr, 0));
        CodeTimer.timeCode(() -> BubbleSort.bubbleSort(arr2));
        CodeTimer.timeCode(() -> BubbleSort.bubbleSort(ShellSort.shellSort(arr3, 4)));

    }
}
